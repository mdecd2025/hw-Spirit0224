from controller import Robot, Keyboard, Emitter
import time
import math

# ==== Constants ====
TIME_STEP = 32
MAX_VELOCITY = 20.0
ANGLE_STEP = 40 * math.pi / 180
POSITION_M = ANGLE_STEP
POSITION_K = 0.0
BALL_WAIT_DELAY = 1.0    # 發球後等待球出現
DELAY_AFTER_M = 1.2      # 拉桿後多等一點
DELAY_AFTER_K = 1.0      # 收回後多等一點

robot = Robot()
timestep = int(robot.getBasicTimeStep())
keyboard = Keyboard()
keyboard.enable(timestep)

motor = robot.getDevice('motor1')
sensor = robot.getDevice('motor1_sensor')
sensor.enable(timestep)
wheels = [robot.getDevice(f"wheel{i+1}") for i in range(4)]
for wheel in wheels:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)

imu = robot.getDevice("imu")
imu.enable(timestep)
gps = robot.getDevice("gps")
gps.enable(timestep)

emitter = robot.getDevice('emitter')

current_state = "allow_m"
key_pressed = {'k': False, 'm': False, 'r': False}

# ==== 點位 ====
U_point = (3.89, 4.99)
U_face = (3.89, 0.63)

# ==== 自動擊球自動移動流程 flag ====
auto_cycle = False
z_stage = 0
z_time = 0

def set_wheel_velocity(v1, v2, v3, v4):
    wheels[0].setVelocity(v1)
    wheels[1].setVelocity(v2)
    wheels[2].setVelocity(v3)
    wheels[3].setVelocity(v4)

def get_yaw():
    return imu.getRollPitchYaw()[2]

def get_position():
    pos = gps.getValues()
    return (pos[0], pos[1])

def angle_diff(a, b):
    d = a - b
    while d > math.pi:
        d -= 2 * math.pi
    while d < -math.pi:
        d += 2 * math.pi
    return d

def angle_between_vectors(ax, ay, bx, by):
    norm_a = math.hypot(ax, ay)
    norm_b = math.hypot(bx, by)
    if norm_a == 0 or norm_b == 0:
        return 0
    ax, ay = ax / norm_a, ay / norm_a
    bx, by = bx / norm_b, by / norm_b
    dot = ax * bx + ay * by
    det = ax * by - ay * bx
    angle_rad = math.atan2(det, dot)
    return math.degrees(angle_rad)

def rotate_by_angle(target_angle_deg, fast_velocity=MAX_VELOCITY, slow_velocity=1.0, tolerance_deg=1.0):
    start_yaw = get_yaw()
    target_rad = math.radians(target_angle_deg)
    slow_zone = math.radians(5)
    direction = -1 if target_angle_deg > 0 else 1

    while True:
        robot.step(timestep)
        now_yaw = get_yaw()
        turned = angle_diff(now_yaw, start_yaw)
        remain = abs(target_rad) - abs(turned)
        if remain < math.radians(tolerance_deg):
            break
        if remain < slow_zone:
            speed = slow_velocity
        else:
            speed = fast_velocity
        set_wheel_velocity(-direction * speed, direction * speed,
                           -direction * speed, direction * speed)
    set_wheel_velocity(0, 0, 0, 0)

def move_to_point_and_face_to(target_point, face_to_point, tolerance_pos=0.05):
    fast_velocity = 10.0
    slow_velocity = 1.0
    MAX_STEP = 1200

    # === 第一階段：轉向目標點 ===
    now_pos = get_position()
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    tar_vec = (target_point[0] - now_pos[0], target_point[1] - now_pos[1])
    angle1 = angle_between_vectors(head_vec[0], head_vec[1], tar_vec[0], tar_vec[1])
    rotate_by_angle(angle1)

    # === 第二階段：前進 ===
    step = 0
    while step < MAX_STEP:
        robot.step(timestep)
        now_pos = get_position()
        dx = target_point[0] - now_pos[0]
        dy = target_point[1] - now_pos[1]
        dist = math.hypot(dx, dy)
        if dist < tolerance_pos:
            break
        v = fast_velocity if dist > 0.3 else slow_velocity
        set_wheel_velocity(v, v, v, v)
        step += 1
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(8):
        robot.step(timestep)

    # === 第三階段：轉向 face_to_point ===
    now_pos = get_position()
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    face_vec = (face_to_point[0] - now_pos[0], face_to_point[1] - now_pos[1])
    angle2 = angle_between_vectors(head_vec[0], head_vec[1], face_vec[0], face_vec[1])
    rotate_by_angle(angle2)
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(8):
        robot.step(timestep)

print("Z鍵：自動 Emitter 叫球->延遲->拉桿(M)+Emitter M->延遲->收回(K)->自動移動到U點")

while robot.step(timestep) != -1:
    key = keyboard.getKey()

    # ====== 按Z鍵進入自動循環 ======
    if key == ord('Z') or key == ord('z'):
        if not auto_cycle:
            print("Z流程開始：發送叫球 Emitter r")
            emitter.send(b"r")
            auto_cycle = True
            z_stage = 1
            z_time = time.time()

    # ====== 自動流程分階段 ======
    if auto_cycle:
        now = time.time()
        if z_stage == 1:
            # 等球產生
            if now - z_time >= BALL_WAIT_DELAY:
                print("自動M（拉桿）+ Emitter M")
                if current_state == "allow_m":
                    motor.setVelocity(5.45)             # <---- 強制指定速度
                    motor.setPosition(POSITION_M)
                    current_state = "allow_k"
                    emitter.send(b"m")  # 新增：發送 M 指令給 supervisor
                    z_time = now
                    z_stage = 2
        elif z_stage == 2:
            # 等待拉桿動作
            if now - z_time >= DELAY_AFTER_M:
                print("自動K（收回）")
                if current_state == "allow_k":
                    motor.setVelocity(10.0)             # <--- 收回也可以慢速
                    motor.setPosition(POSITION_K)
                    current_state = "allow_m"
                    z_time = now
                    z_stage = 3
        elif z_stage == 3:
            # 等待擊球收回動作
            if now - z_time >= DELAY_AFTER_K:
                print("自動移動到U點")
                move_to_point_and_face_to(U_point, U_face)
                auto_cycle = False
                z_stage = 0

    # 你也可以保留手動M/K/R功能
    _current_motor_position = sensor.getValue()
    if key == ord('M') or key == ord('m'):
        if not key_pressed['m'] and current_state == "allow_m":
            print("手動M")
            motor.setVelocity(10.0)         # <---- 這裡也強制指定速度
            motor.setPosition(POSITION_M)
            current_state = "allow_k"
            emitter.send(b"m")  # 新增：手動M時也同步發送m
        key_pressed['m'] = True
    else:
        key_pressed['m'] = False

    if key == ord('K') or key == ord('k'):
        if not key_pressed['k'] and current_state == "allow_k":
            print("手動K")
            motor.setVelocity(10.0)         # <---- 收回速度也可統一
            motor.setPosition(POSITION_K)
            current_state = "allow_m"
        key_pressed['k'] = True
    else:
        key_pressed['k'] = False

    if key == ord('R') or key == ord('r'):
        if not key_pressed['r']:
            current_state = "allow_m"
        key_pressed['r'] = True
    else:
        key_pressed['r'] = False
