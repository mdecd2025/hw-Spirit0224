youbot_cart_w14_w_plate.wbt

size of plate on Youbot cart

length 50 cm
width 30 cm
height 2 cm

youbot_cart_w14_w_plate_small_shooter_feed_ball.wbt

press key "a" to use supervisor to feed a static ball relative to youbot position (default_feed_pos = (-0.35, 0.0, 0.9))

press key "m" to replace the static ball with a dynamic ball and rotate press for 40 degrees to shoot the ball targeted the basket

press key "k" to rotate back the press to the initial position

press arrow keys to control the youbot cart